"""Testes locais sem GIANTS Editor e sem alterar mapa real."""
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from tg_i3d import scene_splines
from TG_Cerca_Editor import load_points, make_xml, safe_write

path = Path(__file__).resolve().parent / 'EXEMPLO' / 'sa.i3d'
assert path.exists(), 'Arquivo EXEMPLO/sa.i3d não disponível'
assert (path.parent/'sa.i3d.shapes').exists()
found=scene_splines(path)
assert len(found)==1 and len(found[0][1])==26
points, detail=load_points(path)
assert len(points) > 26
with tempfile.TemporaryDirectory() as t:
    folder=Path(t)
    fm=folder/'FS25_CercaTeste';fm.mkdir()
    gm=folder/'FS25_PorteiraTeste';gm.mkdir()
    (fm/'modDesc.xml').write_text('<modDesc><storeItems><storeItem xmlFilename="fence.xml"/></storeItems></modDesc>',encoding='utf-8')
    (fm/'fence.xml').write_text('<placeable><fence/></placeable>',encoding='utf-8')
    (gm/'modDesc.xml').write_text('<modDesc><storeItems><storeItem xmlFilename="gate.xml"/></storeItems></modDesc>',encoding='utf-8')
    (gm/'gate.xml').write_text('<placeable><animatedObjects/></placeable>',encoding='utf-8')
    target=folder/'placeables.xml'
    target.write_text('<placeables/>',encoding='utf-8')
    tree,n,length=make_xml(points,fm,'fence.xml',target)
    assert n>10 and 380<length<420
    assert len(tree.findall('.//newFence/segment'))==n
    tree,n_gate,_=make_xml(points,fm,'fence.xml',target,gm,'gate.xml',50,4)
    assert n_gate>0
    assert len(tree.getroot().findall('placeable'))==2
    backup=safe_write(target,tree)
    assert backup.exists()
    ET.parse(target)
    assert len(ET.parse(target).getroot().findall('placeable'))==2
    print('OK - I3D: 26 pontos de controle, spline:',detail)
    print('OK - Cerca gerada no XML de teste:',n,'segmentos e comprimento:',round(length,2),'m')
    print('OK - Porteira gera lacuna e placeable separado')
    print('OK - Backup criado e XML salvo sem erro')
