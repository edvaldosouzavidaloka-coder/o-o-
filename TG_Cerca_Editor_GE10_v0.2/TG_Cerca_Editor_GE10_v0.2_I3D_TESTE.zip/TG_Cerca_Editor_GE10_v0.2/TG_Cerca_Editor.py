"""TOP GAMERS - Cerca por spline FS25 (teste v0.2 I3D).
Python 3.10+ / biblioteca padrao. Iniciar: py TG_Cerca_Editor.py
Projeto experimental - nao gravar no mapa principal sem testes.
"""
from __future__ import annotations
import csv
import math
import os
from pathlib import Path
import shutil
import tempfile
import uuid
import zipfile
import xml.etree.ElementTree as ET
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from tg_i3d import scene_splines, resample_polyline


def mods_default() -> Path:
    return Path.home() / 'Documents' / 'My Games' / 'FarmingSimulator2025' / 'mods'


def read_mod_file(mod: Path, inside: str) -> bytes:
    inside=inside.replace('\\','/')
    if mod.is_dir():
        file=(mod/inside).resolve()
        if not file.is_relative_to(mod.resolve()):
            raise ValueError('Caminho inseguro dentro do mod.')
        return file.read_bytes()
    with zipfile.ZipFile(mod) as z:
        return z.read(inside)


def mod_xml_files(mod: Path) -> list[str]:
    if mod.is_dir():
        return sorted(p.relative_to(mod).as_posix() for p in mod.rglob('*.xml'))
    with zipfile.ZipFile(mod) as z:
        return sorted(s for s in z.namelist() if s.lower().endswith('.xml'))


def mod_name(mod: Path) -> str:
    return mod.stem if mod.is_file() else mod.name


def fsfilename(mod: Path, inside: str):
    return '$moddir$'+mod_name(mod)+'/'+inside.replace('\\','/')


def load_points(path: Path):
    if path.suffix.lower()=='.i3d':
        candidates=scene_splines(path)
        if len(candidates)>1:
            raise ValueError('O I3D possui mais de uma spline. Exporte apenas uma spline por arquivo.')
        name, controls, kind=candidates[0]
        # v0.2 interpola linearmente os pontos de controle. Curvas cubicas no jogo
        # podem diferir, por isso exige verificacao visual antes de usar.
        return resample_polyline(controls, spacing=2), f'I3D ({name}, {len(controls)} pontos {kind}; curva aproximada)'
    if path.suffix.lower()=='.csv':
        with path.open('r', encoding='utf-8-sig', newline='') as f:
            rows=list(csv.DictReader(f))
        pts=[tuple(float(row[k]) for k in ('x','y','z')) for row in rows]
        if len(pts)<2 or not all(math.isfinite(v) for p in pts for v in p):
            raise ValueError('CSV inválido: mínimo dois pontos XYZ válidos.')
        return pts, f'CSV ({len(pts)} pontos)'
    raise ValueError('Selecione spline em formato .i3d ou .csv.')


def check_mod_xml(mod: Path, inside: str, fence=False):
    xml=ET.fromstring(read_mod_file(mod,inside))
    if xml.tag!='placeable':
        raise ValueError(f'XML {inside} não é um placeable.')
    if fence and xml.find('./fence') is None:
        raise ValueError('O XML escolhido não possui <fence>: não há cerca nativa para gerar.')
    return xml


def store_registration(mod: Path, inside: str):
    try:
        desc=ET.fromstring(read_mod_file(mod,'modDesc.xml'))
    except (FileNotFoundError, KeyError, ET.ParseError):
        return False
    paths=[el.get('xmlFilename','').replace('\\','/').lower().lstrip('./')
           for el in desc.findall('.//storeItems/storeItem')]
    return inside.replace('\\','/').lower().lstrip('./') in paths


def cumulative(pts):
    ds=[0.]
    for a,b in zip(pts,pts[1:]):
        ds.append(ds[-1]+math.hypot(b[0]-a[0], b[2]-a[2]))
    return ds


def interpolate(pts, ds, d):
    d=max(0,min(d,ds[-1]))
    for i in range(len(ds)-1):
        if d <= ds[i+1] or i==len(ds)-2:
            t=(d-ds[i])/max(1e-9,ds[i+1]-ds[i])
            return tuple(pts[i][j]+t*(pts[i+1][j]-pts[i][j]) for j in range(3))
    return pts[-1]


def section(pts, ds, a, b):
    if b-a <= 0.05: return []
    return [interpolate(pts,ds,a)] + [pts[i] for i in range(1,len(pts)-1) if a<ds[i]<b] + [interpolate(pts,ds,b)]


def vec(pts):return ' '.join(f'{v:.3f}' for v in pts)


def make_xml(points, fence_mod, fence_xml, target, gate_mod=None, gate_xml='', gate_pct=50., gate_width=4.):
    check_mod_xml(fence_mod,fence_xml, fence=True)
    if gate_mod:
        gate_root=check_mod_xml(gate_mod,gate_xml)
        if gate_root.find('./fence') is not None:
            raise ValueError('Porteira do tipo newFence requer suporte integrado ainda não implementado.')
    tree=ET.parse(target)
    root=tree.getroot()
    if root.tag!='placeables':raise ValueError('Destino precisa de raiz <placeables>.')
    ds=cumulative(points); length=ds[-1]
    if length < 1:raise ValueError('Spline curta demais.')
    if gate_mod:
        if not 0 < gate_width < length:raise ValueError('Largura da porteira inválida.')
        middle=length*(gate_pct/100)
        g0=middle-gate_width/2;g1=middle+gate_width/2
        if g0<0 or g1>length:raise ValueError('Porteira fora dos limites da spline.')
        parts=[section(points,ds,0,g0),section(points,ds,g1,length)]
    else:
        parts=[points]
    fence=ET.SubElement(root,'placeable',{
        'filename':fsfilename(fence_mod,fence_xml),
        'modName':mod_name(fence_mod),
        'uniqueId':'placeable'+uuid.uuid4().hex,
        'position':'0.000 -151.000 0.000','rotation':'0.000 0.000 0.000',
        'age':'0.000000', 'price':'100.000000','farmId':'0'
    })
    els=ET.SubElement(fence,'newFence')
    count=0
    for piece in parts:
        for a,b in zip(piece,piece[1:]):
            if math.hypot(a[0]-b[0],a[2]-b[2])<.01:continue
            ET.SubElement(els,'segment',{'start':vec(a),'end':vec(b),'id':'SEGMENT'})
            count+=1
    if count==0:raise ValueError('Nenhum segmento produzido.')
    if gate_mod:
        ctr=interpolate(points,ds,middle)
        a,b=interpolate(points,ds,g0),interpolate(points,ds,g1)
        angle=math.degrees(math.atan2(b[0]-a[0], b[2]-a[2]))
        ET.SubElement(root,'placeable',{
            'filename':fsfilename(gate_mod,gate_xml),
            'modName':mod_name(gate_mod),
            'uniqueId':'placeable'+uuid.uuid4().hex,
            'position':vec(ctr),'rotation':f'0.000 {angle:.3f} 0.000',
            'age':'0.000000', 'price':'100.000000','farmId':'0'
        })
    return tree,count,length


def safe_write(path, tree):
    backup=path.with_name(path.name+'.tg_backup')
    if not backup.exists():shutil.copy2(path,backup)
    fd,temp=tempfile.mkstemp(prefix='tg_cerca_',suffix='.xml',dir=path.parent)
    os.close(fd)
    try:
        ET.indent(tree,space='    ')
        tree.write(temp,encoding='utf-8',xml_declaration=True)
        ET.parse(temp)
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)
    return backup


class Program(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('TOP GAMERS - Criador de Cercas FS25 | I3D v0.2 TESTE')
        self.geometry('900x770')
        self.minsize(780,650)
        self.modsdir=tk.StringVar(value=str(mods_default()))
        self.path=tk.StringVar()
        self.placeables=tk.StringVar()
        self.storeitems=tk.StringVar()
        self.animated=tk.StringVar()
        self.fencemod=tk.StringVar()
        self.fencexml=tk.StringVar()
        self.gatemod=tk.StringVar()
        self.gatexml=tk.StringVar()
        self.gate_pct=tk.DoubleVar(value=50)
        self.gate_width=tk.DoubleVar(value=4)
        self.dryrun=tk.BooleanVar(value=True)
        self.mods={}
        frm=ttk.Frame(self,padding=12)
        frm.pack(fill='both',expand=True)
        frm.columnconfigure(1,weight=1)
        def entry(row, label, var, filetypes=None, folder=False):
            ttk.Label(frm,text=label).grid(row=row,column=0,sticky='w',pady=4)
            ttk.Entry(frm,textvariable=var).grid(row=row,column=1,sticky='ew',pady=4)
            def choose():
                value=filedialog.askdirectory() if folder else filedialog.askopenfilename(filetypes=filetypes)
                if value: var.set(value)
            ttk.Button(frm,text='Selecionar',command=choose).grid(row=row,column=2,padx=4)
        entry(0,'Pasta mods',self.modsdir,folder=True)
        ttk.Button(frm,text='Carregar mods',command=self.scan).grid(row=1,column=2)
        def combo(row,label,var,key,cb=None):
            ttk.Label(frm,text=label).grid(row=row,column=0,sticky='w',pady=4)
            box=ttk.Combobox(frm,textvariable=var,state='readonly')
            box.grid(row=row,column=1,columnspan=2,sticky='ew',pady=4)
            setattr(self,key,box)
            if cb:box.bind('<<ComboboxSelected>>',cb)
        combo(2,'Mod da cerca',self.fencemod,'fence_mod_box',self.update_fence)
        combo(3,'XML da cerca',self.fencexml,'fence_xml_box')
        combo(4,'Mod da porteira (opcional)',self.gatemod,'gate_mod_box',self.update_gate)
        combo(5,'XML da porteira',self.gatexml,'gate_xml_box')
        entry(6,'Spline exportada (.i3d ou .csv)',self.path,
              [('I3D e CSV','*.i3d *.csv'),('GIANTS Editor I3D','*.i3d'),('CSV','*.csv')])
        ttk.Button(frm,text='Analisar spline (I3D ou CSV)',command=self.analyze).grid(row=7,column=0,columnspan=3,sticky='ew',pady=(2,6))
        entry(8,'placeables.xml do mapa',self.placeables,[('XML','*.xml')])
        entry(9,'storeItems.xml (opcional)',self.storeitems,[('XML','*.xml')])
        entry(10,'animatedObjects.xml (validar, opcional)',self.animated,[('XML','*.xml')])
        ttk.Label(frm,text='Porteira: posição (%)').grid(row=11,column=0,sticky='w')
        ttk.Spinbox(frm,from_=1,to=99,textvariable=self.gate_pct,width=10).grid(row=11,column=1,sticky='w')
        ttk.Label(frm,text='Porteira: largura (m)').grid(row=12,column=0,sticky='w')
        ttk.Spinbox(frm,from_=1,to=20,increment=.5,textvariable=self.gate_width,width=10).grid(row=12,column=1,sticky='w')
        ttk.Checkbutton(frm,text='Só conferir / prévia: não altera os XMLs (recomendado)',variable=self.dryrun).grid(row=13,column=0,columnspan=3,sticky='w',pady=(10,4))
        ttk.Button(frm,text='Conferir / Gerar XML experimental',command=self.generate).grid(row=14,column=0,columnspan=3,sticky='ew')
        ttk.Label(frm,text='Log / mensagens').grid(row=15,column=0,sticky='w',pady=(10,0))
        self.log=tk.Text(frm,height=10,wrap='word')
        self.log.grid(row=16,column=0,columnspan=3,sticky='nsew',pady=(2,0))
        frm.rowconfigure(16,weight=1)
        self.logmsg('Versão 0.2: I3D carregável junto de seu arquivo .i3d.shapes.\n'
                    'CUIDADO: remoção por trechos e porteira animada NÃO estão confirmadas no FS25.\n'
                    'animatedObjects.xml é validado, mas NÃO recebe animações automaticamente.')
        self.scan()

    def logmsg(self,s):
        self.log.insert('end',str(s)+'\n')
        self.log.see('end')

    def scan(self):
        folder=Path(self.modsdir.get())
        if not folder.is_dir():
            self.logmsg('Selecione sua pasta mods antes de carregar.')
            return
        mods=list(folder.glob('*.zip'))+[p for p in folder.iterdir() if p.is_dir() and (p/'modDesc.xml').exists()]
        self.mods={mod_name(p):p for p in mods}
        names=sorted(self.mods,key=str.casefold)
        self.fence_mod_box['values']=names
        self.gate_mod_box['values']=['(sem porteira)']+names
        self.logmsg(f'{len(names)} mods encontrados.')

    def update_fence(self,_=None):
        self.fencexml.set('')
        try:self.fence_xml_box['values']=mod_xml_files(self.mods[self.fencemod.get()])
        except Exception as e:self.logmsg('Erro ao listar XML da cerca: '+str(e))

    def update_gate(self,_=None):
        self.gatexml.set('')
        selected=self.mods.get(self.gatemod.get())
        if selected:
            try:self.gate_xml_box['values']=mod_xml_files(selected)
            except Exception as e:self.logmsg('Erro ao listar XML da porteira: '+str(e))

    def analyze(self):
        try:
            path=Path(self.path.get())
            pts, detail=load_points(path)
            length=cumulative(pts)[-1]
            self.logmsg(f'SPLINE OK: {detail}, amostra de {len(pts)} pontos, aproximadamente {length:.1f} m.')
            self.logmsg('Início: '+vec(pts[0])+'  Fim: '+vec(pts[-1]))
        except Exception as e:
            self.logmsg('ERRO DE SPLINE: '+str(e))
            messagebox.showerror('TOP GAMERS',str(e))

    def generate(self):
        try:
            pts,detail=load_points(Path(self.path.get()))
            fence=self.mods.get(self.fencemod.get())
            if fence is None or not self.fencexml.get():
                raise ValueError('Selecione mod e XML de cerca.')
            gate=self.mods.get(self.gatemod.get())
            gatexml=self.gatexml.get()
            if gate and not gatexml:raise ValueError('Selecione o XML da porteira.')
            dst=Path(self.placeables.get())
            if not dst.is_file():raise ValueError('Selecione o placeables.xml do mapa ou save de teste.')
            for title,entry in [('storeItems',self.storeitems),('animatedObjects',self.animated)]:
                if entry.get().strip():
                    maybe=Path(entry.get()); root=ET.parse(maybe).getroot()
                    if root.tag!=title:
                        raise ValueError(f'Arquivo {title}.xml tem raiz <{root.tag}>; esperado <{title}>.')
                    self.logmsg(f'{title}.xml validado; não será alterado.')
            tree,count,length=make_xml(pts,fence,self.fencexml.get(),dst,gate,gatexml,
                                        self.gate_pct.get(),self.gate_width.get())
            self.logmsg(f'PRÉVIA OK: {detail}; {count} segmentos de cerca; {length:.1f} metros.')
            if not store_registration(fence,self.fencexml.get()):
                self.logmsg('AVISO: XML de cerca não encontrado no <storeItems> do modDesc.')
            if gate:
                self.logmsg('Porteira separada: o XML do mod deve ter a animação pronta e funcional.')
                if not store_registration(gate,gatexml):
                    self.logmsg('AVISO: XML da porteira não encontrado no <storeItems> do modDesc.')
            self.logmsg('AVISO: precisa testar no jogo. I3D cúbico foi aproximado em polilinha.')
            if self.dryrun.get():
                self.logmsg('MODO PRÉVIA: nada foi gravado. Revise antes de desmarcar.')
                return
            backup=safe_write(dst,tree)
            self.logmsg(f'Gravado em: {dst}\nBackup original: {backup}')
            messagebox.showinfo('TOP GAMERS','XML gravado com backup. Teste em um save novo e confira log.txt.')
        except Exception as e:
            self.logmsg('ERRO: '+str(e))
            messagebox.showerror('TOP GAMERS',str(e))


if __name__=='__main__':
    Program().mainloop()
