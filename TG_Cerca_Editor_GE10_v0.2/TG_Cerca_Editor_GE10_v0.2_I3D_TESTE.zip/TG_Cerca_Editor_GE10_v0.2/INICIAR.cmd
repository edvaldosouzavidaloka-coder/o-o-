@echo off
cd /d "%~dp0"
py TG_Cerca_Editor.py
if errorlevel 1 (
  echo.
  echo Nao foi possivel executar. Verifique se Python 3.10+ esta instalado.
  pause
)
