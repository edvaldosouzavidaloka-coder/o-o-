"""Leitor experimental de spline FS25 I3D + .i3d.shapes.
Portao de interoperabilidade de formato (sem alterar I3D) para TOP GAMERS.
O algoritmo da cifra foi estudado na implementacao MIT de Donkie/I3DShapesTool,
via BrewingCoder/giants-fs-codecs (MIT). Consulte CREDITOS.txt.
"""
from __future__ import annotations
import math
import re
import struct
import urllib.request
from pathlib import Path
import xml.etree.ElementTree as ET

MASK = 0xffffffff
# Chave para a semente e5 do arquivo de exemplo sa.i3d.shapes do usuario.
# Outras sementes: leitor adquire tabela publica MIT sob demanda e salva em cache.
KEY_E5 = [0x73767b7b,0x6c65646a,0x5f636a6b,0x57545351,
          0x5a5c5a5b,0xcdc17458,0xcdcdcacc,0xcccccdcc,
          0xcccdcccc,0xd1cfcecc,0xd0cfcbcd,0xd3d2d1d2,
          0xd3d5d4d2,0xd4d5d5d4,0xd9d9d8d7,0xdcdadad9]
KEY_SRC = 'https://raw.githubusercontent.com/BrewingCoder/giants-fs-codecs/master/vendor/I3DCipher.cs'


def key_for_seed(seed):
    if seed == 0xE5:
        return KEY_E5[:]
    cache = Path(__file__).resolve().parent / '_key_table.txt'
    if cache.is_file():
        text = cache.read_text(encoding='utf-8-sig')
    else:
        try:
            with urllib.request.urlopen(KEY_SRC, timeout=12) as reply:
                text = reply.read(150_000).decode('utf-8-sig')
        except Exception as exc:
            raise ValueError(f'O I3D usa a semente {seed}. Sem acesso a tabela de chaves do formato. '
                             f'Conecte a internet ou use um I3D compatível. Erro: {exc}') from exc
        cache.write_text(text, encoding='utf-8')
    match = re.search(r'keyConst\s*=\s*\{(.*?)\}\s*;', text, flags=re.S)
    if match is None:
        raise ValueError('Tabela de chaves com formato desconhecido.')
    vals = [int(n,16) for n in re.findall(r'0x[0-9A-Fa-f]{1,8}', match.group(1))]
    if len(vals) != 4096:
        raise ValueError('Tabela de chaves incompleta.')
    return vals[seed * 16:(seed + 1) * 16]


def _rol(n, count): return ((n << count) | (n >> (32 - count))) & MASK

def _ror(n, count): return ((n >> count) | (n << (32 - count))) & MASK

def _mix_a(k,a,b,c,d):
    k[c] ^= _rol((k[b]+k[a]) & MASK, 7)
    k[d] ^= _rol((k[c]+k[a]) & MASK, 9)
    k[b] ^= _rol((k[c]+k[d]) & MASK, 13)
    k[a] ^= _ror((k[b]+k[d]) & MASK, 14)

def _mix_b(k,a,b,c,d):
    k[c] ^= _rol((k[b]+k[a]) & MASK, 7)
    k[d] ^= _rol((k[b]+k[c]) & MASK, 9)
    k[a] ^= _rol((k[c]+k[d]) & MASK, 13)
    k[b] ^= _ror((k[d]+k[a]) & MASK, 14)

def decipher(data, seedkey, counter):
    state = seedkey[:]
    state[8], state[9] = counter & MASK, counter >> 32
    padded = data + b'\x00' * (-len(data) % 64)
    buf = list(struct.unpack('<'+'I' * (len(padded)//4), padded))
    for i in range(0, len(buf), 16):
        work = state[:]
        for _ in range(10):
            _mix_a(work,0,12,4,8)
            _mix_a(work,5,1,9,13)
            _mix_a(work,10,6,14,2)
            _mix_a(work,15,11,3,7)
            _mix_b(work,3,0,1,2)
            _mix_b(work,4,5,6,7)
            _mix_a(work,10,9,11,8)
            _mix_b(work,14,15,12,13)
        for j in range(16):
            buf[i+j] ^= (state[j] + work[j]) & MASK
        counter += 1
        state[8], state[9] = counter & MASK, counter >> 32
    return struct.pack('<' + 'I' * len(buf), *buf)[:len(data)]


class CipherReader:
    def __init__(self, encrypted, key):
        self.encrypted, self.key, self.pos, self.block = encrypted, key, 0, 0
    def read(self, size):
        if size < 0 or size > 10_000_000:
            raise ValueError('Tamanho de entidade inválido.')
        part = self.encrypted[self.pos:self.pos+size]
        if len(part) != size:
            raise ValueError('Arquivo .shapes incompleto.')
        clear = decipher(part, self.key, self.block)
        self.pos += size
        self.block += (size + 63) // 64
        return clear
    def int(self):
        return struct.unpack('<i', self.read(4))[0]


def spline_entities(shapes_path):
    data = Path(shapes_path).read_bytes()
    if len(data) < 16 or data[0] not in (7, 9, 10):
        raise ValueError('Formato de .i3d.shapes não reconhecido (esperado FS22/FS25).')
    version, seed = data[0], data[2]
    cipher = CipherReader(data[4:], key_for_seed(seed))
    count = cipher.int()
    if not (0 < count < 100_000):
        raise ValueError('Contagem de entidades inválida no arquivo .shapes.')
    splines = {}
    for _ in range(count):
        etype, size = cipher.int(), cipher.int()
        blob = cipher.read(size)
        if etype not in (2, 6):
            continue
        if len(blob) < 32:
            raise ValueError('Entidade de spline inválida.')
        name_len = struct.unpack_from('<i', blob)[0]
        if not 0 <= name_len <= 256:
            raise ValueError('Nome da spline inválido.')
        cursor = (4 + name_len + 3) // 4 * 4
        if cursor + 12 > len(blob):
            raise ValueError('Cabeçalho da spline incompleto.')
        shape_id, flags, npoints = struct.unpack_from('<III', blob, cursor)
        cursor += 12
        if not 2 <= npoints <= 1_000_000:
            raise ValueError(f'Quantidade de pontos inesperada: {npoints}')
        if len(blob) < cursor + 12*npoints + (4 if version >= 10 else 0):
            raise ValueError('Pontos de controle da spline incompletos.')
        points = [struct.unpack_from('<fff', blob, cursor + i*12) for i in range(npoints)]
        if not all(all(math.isfinite(v) for v in p) for p in points):
            raise ValueError('Spline contém coordenadas inválidas.')
        splines[shape_id] = dict(name=blob[4:4+name_len].decode('ascii','replace'), points=points,
                                 closed=bool(flags&1), kind=('cubic' if etype==2 else 'linear'))
    if not splines:
        raise ValueError('Nenhuma spline encontrada no arquivo .i3d.shapes.')
    return splines


def matrix_mul(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def transform_from_xml(node):
    def vals(name, default):
        string = node.get(name)
        if not string: return default
        a = [float(x) for x in string.split()]
        if len(a) != len(default): raise ValueError(f'Transformação {name} inválida.')
        return a
    x,y,z = vals('translation',[0.,0.,0.]); rx,ry,rz = [math.radians(a) for a in vals('rotation',[0.,0.,0.])]
    sx,sy,sz = vals('scale',[1.,1.,1.])
    cx,snx = math.cos(rx), math.sin(rx)
    cy,sny = math.cos(ry), math.sin(ry)
    cz,snz = math.cos(rz), math.sin(rz)
    # T * Rz * Ry * Rx * S (GIANTS usual Euler order). For user sample rotation is identity.
    mx=[[1,0,0,x],[0,1,0,y],[0,0,1,z],[0,0,0,1]]
    mz=[[cz,-snz,0,0],[snz,cz,0,0],[0,0,1,0],[0,0,0,1]]
    my=[[cy,0,sny,0],[0,1,0,0],[-sny,0,cy,0],[0,0,0,1]]
    xx=[[1,0,0,0],[0,cx,-snx,0],[0,snx,cx,0],[0,0,0,1]]
    ss=[[sx,0,0,0],[0,sy,0,0],[0,0,sz,0],[0,0,0,1]]
    return matrix_mul(matrix_mul(matrix_mul(matrix_mul(mx,mz),my),xx),ss)


def scene_splines(i3d_path):
    path=Path(i3d_path)
    root=ET.parse(path).getroot()
    shapes=root.find('./Shapes')
    if shapes is None or not shapes.get('externalShapesFile'):
        raise ValueError('Arquivo I3D não referencia um .i3d.shapes.')
    binary=(path.parent/shapes.get('externalShapesFile')).resolve()
    if not binary.is_file():
        raise ValueError(f'Faltando o arquivo de pontos: {binary.name}. Deixe junto do I3D.')
    byid=spline_entities(binary)
    scene=root.find('./Scene')
    if scene is None:
        raise ValueError('I3D sem Scene.')
    identities=[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
    out=[]
    def walk(element,parent):
        mat=matrix_mul(parent,transform_from_xml(element))
        if element.tag == 'Shape':
            sid=int(element.get('shapeId','-1'))
            if sid in byid:
                spec=byid[sid]
                xyz=[]
                for x,y,z in spec['points']:
                    px=mat[0][0]*x+mat[0][1]*y+mat[0][2]*z+mat[0][3]
                    py=mat[1][0]*x+mat[1][1]*y+mat[1][2]*z+mat[1][3]
                    pz=mat[2][0]*x+mat[2][1]*y+mat[2][2]*z+mat[2][3]
                    xyz.append((px,py,pz))
                out.append((element.get('name',spec['name']),xyz,spec['kind']))
        for ch in element:
            walk(ch,mat)
    for el in scene:
        walk(el,identities)
    if not out:
        raise ValueError('I3D não contém uma spline vinculada ao arquivo .shapes.')
    return out


def resample_polyline(points, spacing=2.0):
    """Amostra linear simples dos pontos de controle. NÃO reproduz a curva cúbica com precisão."""
    if spacing <= 0: raise ValueError('Espaçamento deve ser positivo.')
    cleaned=[points[0]]
    for p in points[1:]:
        if math.dist((p[0],p[2]),(cleaned[-1][0],cleaned[-1][2])) > .001:
            cleaned.append(p)
    output=[cleaned[0]]
    for a,b in zip(cleaned,cleaned[1:]):
        length=math.hypot(b[0]-a[0],b[2]-a[2])
        sections=max(1,math.ceil(length/spacing))
        for j in range(1,sections+1):
            t=j/sections
            output.append(tuple(a[i]+t*(b[i]-a[i]) for i in range(3)))
    return output


if __name__=='__main__':
    import sys
    p=Path(sys.argv[1]); specs=scene_splines(p)
    for name,pts,kind in specs:
        length=sum(math.hypot(b[0]-a[0],b[2]-a[2]) for a,b in zip(pts,pts[1:]))
        print(f'{name}: {len(pts)} pontos {kind}, aproximadamente {length:.1f}m, inicio={pts[0]} fim={pts[-1]}')
